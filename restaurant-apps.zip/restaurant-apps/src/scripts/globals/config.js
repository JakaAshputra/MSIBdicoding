const CONFIG = {
  KEY: '',
  BASE_URL: 'https://restaurant-api.dicoding.dev/',
};

export default CONFIG;
